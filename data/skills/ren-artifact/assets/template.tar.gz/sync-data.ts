import { Database } from "bun:sqlite"
import { mkdir, writeFile } from "node:fs/promises"
import { basename, join } from "node:path"

// Replace the query. Keep the contract: read a pod database, write build/data.json, nothing else.
const SLUG = basename(process.cwd())
const QUERY = "select name from sqlite_master where type = 'table' order by name"

const db = new Database(join("/home/user/db", `${SLUG}.db`), { readonly: true })
const rows = db.query(QUERY).all()
db.close()

await mkdir("build", { recursive: true })
await writeFile(join("build", "data.json"), JSON.stringify({ generatedAt: new Date().toISOString(), rows }, null, 2))
