import { Moon, Sun } from "lucide-react"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"

type Mode = "light" | "dark"

function preferred(): Mode {
  const stored = localStorage.getItem("theme")
  if (stored === "light" || stored === "dark") return stored
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
}

export function ThemeToggle() {
  const [mode, setMode] = useState<Mode>(() => preferred())

  useEffect(() => {
    document.documentElement.classList.toggle("dark", mode === "dark")
    localStorage.setItem("theme", mode)
  }, [mode])

  return (
    <Button
      variant="ghost"
      size="icon"
      aria-label={mode === "dark" ? "Switch to light theme" : "Switch to dark theme"}
      onClick={() => setMode(mode === "dark" ? "light" : "dark")}
    >
      {mode === "dark" ? <Sun /> : <Moon />}
    </Button>
  )
}
