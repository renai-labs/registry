import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ThemeToggle } from "@/theme-toggle"

type Data = {
  generatedAt: string
  rows: Record<string, string | number | null>[]
}

type State = { status: "loading" } | { status: "ready"; data: Data } | { status: "empty"; reason: string }

export function App() {
  const [state, setState] = useState<State>({ status: "loading" })

  useEffect(() => {
    let cancelled = false
    fetch("./data.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error(`data.json responded ${res.status}`))))
      .then((data: Data) => {
        if (!cancelled) setState({ status: "ready", data })
      })
      .catch((err: unknown) => {
        if (!cancelled) setState({ status: "empty", reason: String(err) })
      })
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <main className="mx-auto min-h-screen max-w-[1200px] px-8 py-12">
      <header className="flex items-start justify-between border-b pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Artifact</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {state.status === "ready"
              ? `Generated ${new Date(state.data.generatedAt).toLocaleString()}`
              : "No data yet"}
          </p>
        </div>
        <ThemeToggle />
      </header>

      {state.status === "ready" ? <Rows rows={state.data.rows} /> : <Placeholder state={state} />}
    </main>
  )
}

function Placeholder({ state }: { state: Extract<State, { status: "loading" | "empty" }> }) {
  if (state.status === "loading") return <p className="pt-8 text-muted-foreground">Loading…</p>
  return (
    <div className="pt-8 text-muted-foreground">
      <p>Run `bun run sync-data` to write build/data.json.</p>
      <p className="pt-2 font-mono text-xs">{state.reason}</p>
    </div>
  )
}

function Rows({ rows }: { rows: Data["rows"] }) {
  if (rows.length === 0) return <p className="pt-8 text-muted-foreground">No rows.</p>
  const columns = Object.keys(rows[0])
  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle>Results</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={column}>{column}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={index}>
                {columns.map((column) => (
                  <TableCell key={column}>{row[column] ?? "—"}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
